/**
 * Toutes les sources disponibles, qui doivent implémenter l'interface SourceInterface
 */
package sources;