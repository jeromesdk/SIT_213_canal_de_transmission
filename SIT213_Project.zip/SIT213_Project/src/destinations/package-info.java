/**
 * Toutes les destinations, qui doivent implémenter l'interface DestinationINterface
 */
package destinations;