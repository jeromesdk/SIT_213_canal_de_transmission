package signaux;

import information.Information;

public class SignalRZ<R, E> extends Signal<R, E>{

	
	public Information<R> generer(){
		
	}
}
