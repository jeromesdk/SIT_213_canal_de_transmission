package recepteurs;

public class recepteur {

}
