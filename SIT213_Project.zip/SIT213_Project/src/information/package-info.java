/**
 * Les source/transmetteurs/recepteur s'envoient des "information"
 */
package information;